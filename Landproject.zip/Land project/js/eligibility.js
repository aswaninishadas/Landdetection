let userList=[];
$('#logout').on('click',(e)=>{
    e.preventDefault();
    localStorage.removeItem('web_token');
    window.location='index.html';
})


$('#applicantsName').on('change',(v)=>{
    console.log('changed');
    $('#area').attr("disabled", false);
})
$('#cardNumber').on('blur',(e)=>{
    e.preventDefault();
    userList=[];
    $('#applicantsName').attr("disabled", true);
    $('#applicantsName').html("");
    if($('#cardNumber').val().trim().length>0){
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", "Bearer "+localStorage.getItem('web_token'));
        fetch(baseURL+'/member/list/'+$('#cardNumber').val(), {
                method: 'GET', // or 'PUT'
                headers: myHeaders
            })
            .then((response) => {
                console.log(response); 
                if(response.ok){
                    return response.json()
                }else{
                    return [];
                }
            })
            .then(data => {
                console.log('Success:', data);
                if(data && data.length>0){
                    userList=data;
                    $('#applicantsName').attr("disabled", false);   
                    $('#area').attr("disabled", false);                 
                }else{
                    userList=[];
                }
                populateApplicantsName();
            })
            .catch((error) => {
                console.error('Error:', error);
                userList=[];
                $('#applicantsName').attr("disabled", true);
                $('#area').attr("disabled", true);
                populateApplicantsName();
        });
    }
})

$('#cardNumber').on('keyup',(e)=>{
    console.log(e);
    $('#applicantsName').html('<option value="-1 disabled selected>Applicant Name</option>');
    $('#applicantsName').attr("disabled", true);
    $('#area').attr("disabled", true);
});

function populateApplicantsName(){
    if(userList.length>0){
        $('#applicantsName').html('<option value="-1" disabled selected>Applicant Name</option>');
        Array.from(userList).forEach((v)=>{
            $('#applicantsName').append('<option value="'+v.memberId+'">'+v.firstName+" "+v.lastName+'</option>');
        })
    }else{
        $('#applicantsName').html('<option value="-1" disabled selected>Applicant Name</option>');
    }
}

function checkEligibility(){
    if($('#isAgri').is(":checked") && $('#cardNumber').val()!="" && $('#applicantsName').val()!=null && $('#area').val()!=""){
        alert('Eligible');
    }else if($('#cardNumber').val()!="" && $('#applicantsName').val()!=null && $('#area').val()!=""){
        //hit api
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", "Bearer "+localStorage.getItem('web_token'));
        fetch(baseURL+'/eligibility/check/'+$('#cardNumber').val()+'/'+$('#area').val()+'/'+$('#isAgri').is(":checked"), {
            method: 'POST', // or 'PUT'
            headers: myHeaders
        })
        .then((response) => {
            console.log(response); 
            if(response.ok){
                return response.json();
            }else{
                return "Server Error Occured. Please try again";
            }
        })
        .then(data => {
            console.log('Success:', data);
            if(data.detail && data.detail.message){
                alert(data.detail.message);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            if(error.detail && error.detail.message){
                alert(error.detail.message);
            }else{
                alert("Server Error Occured. Please try again later");
            }
            
            
    });
    }else{
        alert("Validation Error. Please fill the details properly and try again");
    }
}
