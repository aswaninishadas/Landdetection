function loginSubmit(e){
    e.preventDefault();
    console.log("FOrm submitted");
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    
    if($('#username').val().trim()!="" && $('#password').val()!=""){
        fetch(baseURL + '/user/login', {
                method: 'POST', // or 'PUT'
                headers: myHeaders,
                redirect: 'follow',
                body: JSON.stringify({
                    "userName": $('#username').val(),
                    "password": $('#password').val()
                }),
            })
            .then((response) => {
                console.log(response);
                return response.json();
            })
            .then(data => {
                    console.log('Success:', data);
                    if(data.access_token){
                        localStorage.setItem('web_token',data.access_token);
                        window.location='eligibility.html';
                    }else{
                        alert("No token found");
                    }
                })
            .catch((error) => {
                localStorage.removeItem('web_token');
                console.error('Error:', error);
        });
    }
}